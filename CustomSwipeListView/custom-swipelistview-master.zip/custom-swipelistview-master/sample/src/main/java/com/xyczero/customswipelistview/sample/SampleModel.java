package com.xyczero.customswipelistview.sample;

public class SampleModel {

    private String mTestTitle;
    private String mTestDate;

    public String getTestTitle() {
        return mTestTitle;
    }

    public void setTestTitle(String name) {
        this.mTestTitle = name;
    }

    public String getTestDate() {
        return mTestDate;
    }

    public void setTestDate(String date) {
        this.mTestDate = date;
    }
}
